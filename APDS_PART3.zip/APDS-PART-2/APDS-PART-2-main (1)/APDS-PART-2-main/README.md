Dorcas Mupataie ST10285710
Obianuju Udodi ST10398118
Part 2- Secure Payment API

Is more of a robust, that secures the banking API built with DevSecOps principles, this features more comprehensive authentication, payment processing, and enterprise-grade security measures.

Quick Start

Requirements
	Node.js 18+
	MongoDB 6+
	OpenSSL

Installations

1. Clone repository
bash
git clone : Create new workflow · Obianuju345/APDSPART2

2. Dependencies and installations
bash
npm install

3. setting up the enviroment
bash
cp .env.example .env

Configure your environment variables in .env

4. Generating the SSL certificates
bash
openssl genrsa -out keys/key.pem 4096
openssl req -new -key keys/key.pem -out keys/csr.pem -subj "/C=ZA/ST=Gauteng/L=Johannesburg/O=APDS/CN=localhost"
openssl x509 -req -days 365 -in keys/csr.pem -signkey keys/key.pem -out keys/cert.pem
```

5. Starting up the server
bash
npm run dev


The security features included

User authentication and authorization
	JWT Token Authentication (24 hour expiration)
	Role-Based Access Control (Customer or Admin)
	bcrypt Password Hashing (12 salt rounds)
	HTTPS/SSL Encryption enforced

Input of validations and sanitization
	RegEx Whitelisting for all user inputs
	SQL Injection Protection via MongoDB parameterization
	XSS Prevention through input sanitization
	Strict Data Type Validation

Protection against any potential attacks
	This is the rating Limits (100 requests/15 minutes)
	Brute Force Protection with account lockout
	CORS Configuration for CSRF protection
	Securing any Error Handling that prevents any data exposure

The architecture of the system

The user roles include:
- Customers: Register, login, creating payments and to view personal data
- Admins: Management of payments, approving transactions, employee management

The database schema
	customers: The user accounts with more secure credentials
	employees: Admin and staff accounts
	payments: The payment records with approval workflow

The endpoints of the API

The authentication endpoints
	POST /auth/login - Customer logins
	POST /auth/admin-login - Admin logins
	GET /auth/verify - Token verifications

The user management of endpoints
o	POST /user/register – This is the customer registration
o	POST /user/verify-password - Password verification

The payment system endpoints
o	POST /payments/create - Create payment (Customer auth required)
o	GET /payments/pending - View pending payments (Admin auth required)
o	PATCH /payments/approve/:id - Approve payment (Admin auth required)
o	DELETE /payments/cancel/:id - Cancel payment (Admin auth required)

The functions of the admin endpoints
o	POST /admin/employees - Create employee accounts (Admin auth required)
o	GET /admin/username/:username - Get employee by username (Admin auth required)

The demonstration and functions

The demonstration of commands

1.  The authentication requirement test:
bash
curl -k -X POST https://localhost:3000/payments/create


2. The role-based access control test:
bash
curl -k -H "Authorization: Bearer CUSTOMER_TOKEN" https://localhost:3000/payments/pending


3. Input validation testing:
bash
curl -k -X POST https://localhost:3000/user/register -H "Content-Type: application/json" -d '{"fullName":"Test123", "email":"invalid-email", "password":"short"}'

The features that will be showcased:
	JWT Authentication: Is more token-based secure access
	Role-Based Permissions: This is the customer or admin capabilities
	Input Validation: RegEx-based data sanitization
	Password Security: bcrypt hashing demonstration
	HTTPS Encryption: Secure communication channels
	Rate Limiting: Brute force attack prevention

 CONFIGURATION

The environment variables
```
PORT=3000
MONGODB_URI=mongodb://localhost:27017/adbs_database
JWT_SECRET=your_jwt_secret_key
NODE_ENV=development
```

Setting up the SSL certifications
The system requires SSL certificates for HTTPS. Generate them using OpenSSL as shown in the installation steps or the use of your organization's certificates.

Structure of the project
```
backend/
  routes/           - API route handlers
  middleware/       - Authentication & security
  db/              - Database configurations
  keys/            - SSL certificates
  server.mjs       - Main server file
  package.json     - Dependencies & scripts
```

Contribution
1. Fork of  the repository
2. The creation of a feature branch: `git checkout -b feature/amazing-feature`
3. Committing of your changes: `git commit -m 'Add amazing feature'`
4. Push to the branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

Licenses
This project is the licensed that is under the MIT License - see the LICENSE file for details.

Built for the security of banking solutions as APDS assignment part 2.

Github link:
https://github.com/Obianuju345/APDSPART2-2-/tree/main
Demonstration video
https://www.youtube.com/watch?v=U2U6F_4JSq4&t=1s


