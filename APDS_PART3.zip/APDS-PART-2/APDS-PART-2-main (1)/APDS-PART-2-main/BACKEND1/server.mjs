import https from "https";
import express from 'express';
import cors from 'cors';
import fs from "fs";
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import admin from "./routes/admin.mjs";
import users from "./routes/user.mjs";
import payments from "./routes/payments.mjs";
import auth from "./routes/auth.mjs"; 
import dotenv from "dotenv";
import db from "./db/conn.mjs";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const PORT = 3000;
const app = express();

//  SECURITY MIDDLEWARE (Add these)
app.use(helmet()); // Security headers
app.use(cors());
app.use(express.json());

//  RATE LIMITING
const limiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 3, // Limit each IP to 100 requests per windowMs
    message: {
        error: "Too many requests, please try again after 1 minute"
    }
});
app.use(limiter);


// Routes
app.get("/", (req, res) => {
  res.json({ 
    message: "APDS Backend Server is running!",
    status: "OK",
    timestamp: new Date().toISOString(),
    security: "HTTPS, Input Validation, Rate Limiting, Password Hashing"
  });
});

app.get("/health", (req, res) => {
  res.json({
    status: "healthy",
    server: "running",
    environment: process.env.NODE_ENV || "development",
    security: "Helmet.js, Rate Limiting, CORS"
  });
});

app.use("/auth", auth);
app.use("/admin", admin);
app.use("/user", users);
app.use("/payments", payments);

// HTTPS server
const options = {
  key: fs.readFileSync(join(__dirname, 'keys', 'key.pem')),
  cert: fs.readFileSync(join(__dirname, 'keys', 'cert.pem'))
};

const server = https.createServer(options, app);

server.listen(PORT, () => {
  console.log(` HTTPS server listening on https://localhost:${PORT}`);
  console.log(`  Security Features Enabled:`);
  console.log(`   - HTTPS/SSL Encryption`);
  console.log(`   - Helmet.js Security Headers`);
  console.log(`   - Rate Limiting (100 requests/15min)`);
  console.log(`   - CORS Protection`);
  console.log(` Available Routes:`);
  console.log(`   - https://localhost:${PORT}/`);
  console.log(`   - https://localhost:${PORT}/health`);
  console.log(`   - https://localhost:${PORT}/admin`);
  console.log(`   - https://localhost:${PORT}/user`);
  console.log(`⚠️  Click 'Advanced' → 'Proceed to localhost' for SSL warning`);
});