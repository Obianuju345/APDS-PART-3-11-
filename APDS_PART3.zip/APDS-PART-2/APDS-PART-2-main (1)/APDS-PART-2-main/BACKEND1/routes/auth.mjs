import express from "express";
import bcrypt from "bcrypt";
import db from "../db/conn.mjs";
import { generateToken } from "../middleware/auth.mjs";

const router = express.Router();

// Customer login
router.post("/login", async (req, res) => {
    try {
        const { accountNumber, password } = req.body;

        if (!accountNumber || !password) {
            return res.status(400).json({ error: "Account number and password required" });
        }

        // Find customer
        const customer = await db.collection("customers").findOne({ accountNumber });
        if (!customer) {
            return res.status(401).json({ error: "Invalid credentials" });
        }

        // Verify password
        const isValid = await bcrypt.compare(password, customer.password);
        if (!isValid) {
            return res.status(401).json({ error: "Invalid credentials" });
        }

        // Generate token
        const token = generateToken({
            userId: customer._id.toString(),
            accountNumber: customer.accountNumber,
            role: 'customer',
            name: customer.fullName
        });

        res.json({
            message: "Login successful",
            token: token,
            user: {
                name: customer.fullName,
                accountNumber: customer.accountNumber,
                role: 'customer'
            }
        });
    } catch (error) {
        console.error("Login error:", error);
        res.status(500).json({ error: "Login failed" });
    }
});

// Admin login
router.post("/admin-login", async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ error: "Username and password required" });
        }

        // Find admin (using employees collection for now)
        const admin = await db.collection("employees").findOne({ username });
        if (!admin) {
            return res.status(401).json({ error: "Invalid credentials" });
        }

        // In real system, you'd verify hashed password
        // For demo, we'll use a simple check
        const isValid = password === "admin123"; // Simple demo password

        if (!isValid) {
            return res.status(401).json({ error: "Invalid credentials" });
        }

        // Generate admin token
        const token = generateToken({
            userId: admin._id.toString(),
            username: admin.username,
            role: 'admin',
            name: admin.name
        });

        res.json({
            message: "Admin login successful",
            token: token,
            user: {
                name: admin.name,
                username: admin.username,
                role: 'admin'
            }
        });
    } catch (error) {
        console.error("Admin login error:", error);
        res.status(500).json({ error: "Login failed" });
    }
});

// Verify token endpoint
import { authenticateToken } from "../middleware/auth.mjs";
router.get("/verify", authenticateToken, (req, res) => {
    res.json({
        valid: true,
        user: req.user
    });
});

export default router;