import express from "express";
import db from "../db/conn.mjs";
import { ObjectId } from "mongodb";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import rateLimit from 'express-rate-limit';

const router = express.Router();

router.get("/", async (req, res) => {
    try {
        res.json({ 
            message: "Admin routes are working!",
            available_endpoints: [
                "GET /admin/",
                "GET /admin/username/:username",
                "PATCH /admin/approve/:id", 
                "POST /admin/employees",
                "DELETE /admin/cancel/:id"
            ],
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.get("/username/:username", async (req, res) => {
    try {
        const employee = await db.collection("employees").findOne({username: req.params.username});

        if(!employee) return res.status(404).send("Employee not Found");
        res.status(200).json(employee);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
})

router.patch('/approve/:id', async (req, res) => {
    try {
        const query = {_id: new ObjectId(req.params.id)};
        const updates = {
            $set: {
                approvedBy: req.body.employeeName,
                approvedAt: new Date(),
                status: "approved",
            }
        };

        const result = await db.collection("payments").updateOne(query, updates);
        res.status(200).json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.post("/employees", async (req, res) => {
    try {
        const { username, name, email, position } = req.body;

        if (!username || !name || !email || !position) {
            return res.status(400).json({ message: "All fields are required" });
        }

        const employees = db.collection("employees");

        const existingEmployee = await employees.findOne({
            $or: [{ username }, { email }],
        });
        if (existingEmployee) {
            return res.status(409).json({ message: "Employee already exists" });
        }

        const newEmployee = {
            username,
            name,
            email,
            position,
            createdAt: new Date(),
        };

        const result = await employees.insertOne(newEmployee);

        res.status(201).json({
            message: "Employee created successfully",
            employeeId: result.insertedId,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Error creating employee" });
    }
});

router.delete("/cancel/:id", async (req, res) => {
    try {
        const result = await db.collection("payments").deleteOne({ // ✅ FIXED: "payments"
            _id: new ObjectId(req.params.id)
        });
        res.status(200).json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;