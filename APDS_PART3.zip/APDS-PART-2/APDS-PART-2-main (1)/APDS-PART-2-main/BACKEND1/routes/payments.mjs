import express from "express";
import db from "../db/conn.mjs";
import { ObjectId } from "mongodb";
import { authenticateToken, requireAdmin } from "../middleware/auth.mjs";

const router = express.Router();

// Root route - public
router.get("/", async (req, res) => {
    try {
        res.json({ 
            message: "Payment routes are working!",
            available_endpoints: [
                "POST /payments/create (Customer Auth Required)",
                "GET /payments/pending (Admin Auth Required)",
                "GET /payments/:id (Customer/Admin Auth)",
                "PATCH /payments/approve/:id (Admin Auth Required)", 
                "DELETE /payments/cancel/:id (Admin Auth Required)"
            ],
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Create a new payment - REQUIRES CUSTOMER AUTH
router.post("/create", authenticateToken, async (req, res) => {
    try {
        // ✅ SECURITY: Only customers can create payments
        if (req.user.role !== 'customer') {
            return res.status(403).json({ error: "Only customers can create payments" });
        }

        console.log("💰 Payment creation by:", req.user.accountNumber);
        
        const { amount, description, paymentType } = req.body;

        // ✅ SECURITY: Enhanced validation
        if (!amount || !description) {
            return res.status(400).json({ error: "Amount and description are required" });
        }

        // ✅ SECURITY: Amount validation
        const amountNum = parseFloat(amount);
        if (isNaN(amountNum) || amountNum <= 0) {
            return res.status(400).json({ error: "Amount must be a positive number" });
        }
        if (amountNum > 1000000) {
            return res.status(400).json({ error: "Amount exceeds limit of 1,000,000" });
        }

        // ✅ SECURITY: Get customer from token (not from request body)
        const customer = await db.collection("customers").findOne({ 
            accountNumber: req.user.accountNumber 
        });

        if (!customer) {
            return res.status(404).json({ error: "Customer not found" });
        }

        // Create payment record with audit info
        const newPayment = {
            customerAccount: req.user.accountNumber, // From token, not request
            customerName: customer.fullName,
            amount: amountNum,
            description,
            paymentType: paymentType || "general",
            status: "pending",
            createdAt: new Date(),
            createdBy: req.user.accountNumber,
            approvedBy: null,
            approvedAt: null,
            ipAddress: req.ip // ✅ SECURITY: Track request IP
        };

        const result = await db.collection("payments").insertOne(newPayment);

        console.log("✅ Payment created by customer:", req.user.accountNumber);

        res.status(201).json({
            message: "Payment created successfully",
            paymentId: result.insertedId,
            status: "pending",
            customerName: customer.fullName
        });
    } catch (error) {
        console.error("❌ Payment creation error:", error);
        res.status(500).json({ error: "Payment processing error" });
    }
});

// Get all pending payments - REQUIRES ADMIN AUTH
router.get("/pending", authenticateToken, requireAdmin, async (req, res) => {
    try {
        console.log("👑 Admin accessing pending payments:", req.user.username);

        const pendingPayments = await db.collection("payments")
            .find({ status: "pending" })
            .sort({ createdAt: -1 })
            .toArray();

        res.json({
            message: "Pending payments retrieved",
            count: pendingPayments.length,
            payments: pendingPayments,
            accessedBy: req.user.username
        });
    } catch (error) {
        console.error("Error fetching pending payments:", error);
        res.status(500).json({ error: error.message });
    }
});

// Get payment by ID - REQUIRES AUTH (customer can see their own, admin can see all)
router.get("/:id", authenticateToken, async (req, res) => {
    try {
        const payment = await db.collection("payments").findOne({
            _id: new ObjectId(req.params.id)
        });

        if (!payment) {
            return res.status(404).json({ error: "Payment not found" });
        }

        // ✅ SECURITY: Customers can only see their own payments
        if (req.user.role === 'customer' && payment.customerAccount !== req.user.accountNumber) {
            return res.status(403).json({ error: "Access denied" });
        }

        res.json(payment);
    } catch (error) {
        console.error("Error fetching payment:", error);
        res.status(500).json({ error: error.message });
    }
});

// Approve payment - REQUIRES ADMIN AUTH
router.patch("/approve/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
        console.log("✅ Payment approval by admin:", req.user.username);
        
        const query = { _id: new ObjectId(req.params.id) };
        const updates = {
            $set: {
                approvedBy: req.user.username, // From token, not request body
                approvedAt: new Date(),
                status: "approved",
            }
        };

        const result = await db.collection("payments").updateOne(query, updates);

        if (result.matchedCount === 0) {
            return res.status(404).json({ error: "Payment not found" });
        }

        res.json({
            message: "Payment approved successfully",
            approvedBy: req.user.username,
            approvedAt: new Date()
        });
    } catch (error) {
        console.error("Payment approval error:", error);
        res.status(500).json({ error: error.message });
    }
});

// Cancel/Reject payment - REQUIRES ADMIN AUTH
router.delete("/cancel/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
        console.log("❌ Payment cancellation by admin:", req.user.username);

        const result = await db.collection("payments").deleteOne({
            _id: new ObjectId(req.params.id)
        });

        if (result.deletedCount === 0) {
            return res.status(404).json({ error: "Payment not found" });
        }

        res.json({ 
            message: "Payment cancelled successfully",
            deletedCount: result.deletedCount,
            cancelledBy: req.user.username
        });
    } catch (error) {
        console.error("Payment cancellation error:", error);
        res.status(500).json({ error: error.message });
    }
});

export default router;