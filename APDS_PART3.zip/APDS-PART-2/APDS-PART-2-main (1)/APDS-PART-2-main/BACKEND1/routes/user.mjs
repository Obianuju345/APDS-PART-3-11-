import express from "express";
import bcrypt from "bcrypt";
import db from "../db/conn.mjs";

const router = express.Router();

// REGEX PATTERNS FOR INPUT WHITELISTING
const validationPatterns = {
    // Name: 2-50 characters, letters and spaces only
    fullName: /^[A-Za-zÀ-ÿ\s.'-]{2,50}$/,
    
    // South African ID: 13 digits exactly
    idNumber: /^[0-9]{13}$/,
    
    // Account number: 6-20 alphanumeric characters
    accountNumber: /^[A-Z0-9]{6,20}$/,
    
    // Password: min 8 chars, 1 uppercase, 1 lowercase, 1 number, 1 special character
    password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/
};

// INPUT SANITIZATION FUNCTION
const sanitizeInput = (input) => {
    if (typeof input !== 'string') return input;
    return input.trim().replace(/[<>]/g, ''); // Remove potential HTML tags
};

// Root route
router.get("/", async (req, res) => {
    try {
        res.json({ 
            message: "User routes are working!",
            available_endpoints: [
                "GET /user/",
                "POST /user/register",
                "POST /user/verify-password"  
            ],
            security_features: [
                "Password hashing with bcrypt",
                "Input validation with RegEx",
                "Input sanitization",
                "Duplicate account prevention",
                "SQL injection protection"
            ],
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.post("/register", async (req, res) => {
  try {
    console.log(" Registration attempt:", req.body);
    
    // INPUT SANITIZATION
    const sanitizedBody = {
        fullName: sanitizeInput(req.body.fullName),
        idNumber: sanitizeInput(req.body.idNumber),
        accountNumber: sanitizeInput(req.body.accountNumber),
        password: req.body.password // Don't sanitize password (affects hashing)
    };
    
    const { fullName, idNumber, accountNumber, password } = sanitizedBody;
    
    // BASIC VALIDATION
    if (!fullName || !idNumber || !accountNumber || !password) {
      return res.status(400).json({ error: "All fields are required" });
    }

    // REGEX VALIDATION
    if (!validationPatterns.fullName.test(fullName)) {
        return res.status(400).json({ 
            error: "Invalid name format. Use 2-50 letters and spaces only." 
        });
    }
    
    if (!validationPatterns.idNumber.test(idNumber)) {
        return res.status(400).json({ 
            error: "Invalid ID number. Must be exactly 13 digits." 
        });
    }
    
    if (!validationPatterns.accountNumber.test(accountNumber)) {
        return res.status(400).json({ 
            error: "Invalid account number. Use 6-20 alphanumeric characters." 
        });
    }
    
    if (!validationPatterns.password.test(password)) {
        return res.status(400).json({ 
            error: "Password must be at least 8 characters with uppercase, lowercase, number and special character (@$!%*?&)." 
        });
    }

    // DATABASE CONNECTION CHECK
    if (!db || !db.collection) {
      console.log("❌ Database not connected");
      return res.status(500).json({ error: "Database not available" });
    }

    // DUPLICATE ACCOUNT PREVENTION
    const existing = await db.collection("customers").findOne({ accountNumber });
    if (existing) {
      return res.status(400).json({ error: "Account already registered" });
    }

    // PASSWORD HASHING WITH BCRYPT (12 salt rounds)
    const hashed = await bcrypt.hash(password, 12);

    // SAFE DATABASE INSERTION (MongoDB prevents SQL injection)
    const result = await db.collection("customers").insertOne({
      fullName,
      idNumber,
      accountNumber,
      password: hashed,
      createdAt: new Date(),
    });

    console.log("User registered successfully:", result.insertedId);
    
    res.status(201).json({ 
      message: "Customer registered successfully",
      userId: result.insertedId,
      security_notice: "Password securely hashed and input validated"
    });
    
  } catch (error) {
    console.error("Registration error:", error);
    
    // SECURE ERROR HANDLING (don't expose sensitive info)
    const safeError = error.message.includes("password") ? "Security error" : error.message;
    
    res.status(500).json({ 
      error: "Server error",
      details: safeError 
    });
  }
}); 


router.post("/verify-password", async (req, res) => {
    try {
        console.log(" Password verification attempt:", req.body);
        
        const { accountNumber, password } = req.body;
        
        if (!accountNumber || !password) {
            return res.status(400).json({ error: "Account number and password required" });
        }

        // Find user in database
        const user = await db.collection("customers").findOne({ accountNumber });
        if (!user) {
            return res.status(404).json({ error: "User not found" });
        }
        
        console.log("Stored hash:", user.password);
        console.log("Input password:", password);
        
        // Verify password against stored hash
        const isMatch = await bcrypt.compare(password, user.password);
        
        console.log("Password match:", isMatch);
        
        res.json({
            message: isMatch ? " Password correct!" : " Password incorrect!",
            accountNumber: accountNumber,
            storedHash: user.password,
            inputPassword: password,
            matches: isMatch,
            security: "bcrypt hashing verified"
        });
    } catch (error) {
        console.error("Verification error:", error);
        res.status(500).json({ error: error.message });
    }
});

export default router;