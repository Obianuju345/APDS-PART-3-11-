import { MongoClient } from "mongodb";
import dotenv from "dotenv";
dotenv.config();

// Local MongoDB connection - no SSL needed!
const connectionString = "mongodb://localhost:27017/apds_database";

console.log('🔐 Attempting LOCAL MongoDB connection...');
console.log('Using:', connectionString);

const client = new MongoClient(connectionString, {
    serverSelectionTimeoutMS: 5000,
    connectTimeoutMS: 10000
});

let db;

try {
    console.log('⏳ Connecting to LOCAL MongoDB...');
    await client.connect();
    
    db = client.db();
    console.log('✅ LOCAL MongoDB connected successfully!');
    
    // Create collections if they don't exist
    const collections = await db.listCollections().toArray();
    const collectionNames = collections.map(c => c.name);
    console.log('📁 Current collections:', collectionNames);
    
    const requiredCollections = ['customers', 'employees', 'payments'];
    
    for (const collName of requiredCollections) {
        if (!collectionNames.includes(collName)) {
            await db.createCollection(collName);
            console.log(`✅ Created collection: ${collName}`);
        }
    }
    
} catch(e) {
    console.error("❌ LOCAL MongoDB connection failed: ", e.message);
    console.log('💡 The MongoDB service is running but connection failed');
    console.log('💡 This might be a path or permission issue');
    
    // Fallback database
    db = {
        collection: (name) => ({
            find: () => ({ toArray: () => Promise.resolve([]) }),
            findOne: () => Promise.resolve(null),
            insertOne: (doc) => Promise.resolve({ 
                insertedId: 'local_fallback_' + Date.now()
            }),
        })
    };
    console.log('🔄 Using fallback database for now');
}

export default db;